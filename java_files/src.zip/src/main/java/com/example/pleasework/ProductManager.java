package com.example.pleasework;

import android.graphics.Bitmap;

import java.io.ByteArrayOutputStream;

import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class ProductManager {
    private OkHttpClient client;
    private static final String ADD_PRODUCT_URL = "https://lamp.ms.wits.ac.za/home/s2571291/addproduct.php";

    public ProductManager() {
        client = new OkHttpClient();
    }

    public void addProduct(String productName, String productDescription, double productPrice, String category, Bitmap bitmap, Callback callback) {
        int maxTargetWidth = 800;
        int maxTargetHeight = 600;

        // Calculate the actual target width and height while maintaining the aspect ratio
        int originalWidth = bitmap.getWidth();
        int originalHeight = bitmap.getHeight();
        int targetWidth;
        int targetHeight;

        if (originalWidth > originalHeight) {
            // Landscape orientation
            targetWidth = Math.min(originalWidth, maxTargetWidth);
            targetHeight = (int) (targetWidth * (float) originalHeight / originalWidth);
        } else {
            // Portrait or square orientation
            targetHeight = Math.min(originalHeight, maxTargetHeight);
            targetWidth = (int) (targetHeight * (float) originalWidth / originalHeight);
        }

        // Resize the bitmap to the target width and height
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true);

        // Compress the resized bitmap
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        byte[] imageBytes = stream.toByteArray();

        // Create the request body with the resized and compressed image
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("name", productName)
                .addFormDataPart("description", productDescription)
                .addFormDataPart("price", String.valueOf(productPrice))
                .addFormDataPart("category", category)
                .addFormDataPart("productImage", "product.jpg", RequestBody.create(MediaType.parse("image/jpeg"), imageBytes))
                .build();

        // Create the request and enqueue it
        Request request = new Request.Builder()
                .url(ADD_PRODUCT_URL)
                .post(requestBody)
                .build();

        client.newCall(request).enqueue(callback);
    }

    // Other methods related to product management can be added here
    private static final String SEARCH_PRODUCT_URL = "https://lamp.ms.wits.ac.za/home/s2571291/searchproduct.php";

    public void searchProduct(String query, Callback callback) {
        RequestBody requestBody = new FormBody.Builder()
                .add("query", query)
                .build();

        Request request = new Request.Builder()
                .url(SEARCH_PRODUCT_URL)
                .post(requestBody)
                .build();

        client.newCall(request).enqueue(callback);
    }
}
