package com.example.pleasework;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button searchButton;
    private EditText searchEditText;
    private static final int PICK_IMAGE_REQUEST = 1;


    private Button addProductButton;

    private static final String BASE_URL = "http://lamp.ms.wits.ac.za";

    private static final String LOGIN_URL = BASE_URL + "/login.php";
    private static final String ADD_PRODUCT_URL = BASE_URL + "/addproduct.php";
    private static  final String SEARCH_PRODUCT_URL=BASE_URL +"/searchproduct.php";

    private OkHttpClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.addProductButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to navigate to the second screen
                Intent intent = new Intent(MainActivity.this, productM.class);
                startActivity(intent);
            }
        });
        searchButton = findViewById(R.id.search_button);
        searchEditText = findViewById(R.id.searchEditText);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String query = searchEditText.getText().toString();
                searchProduct(query);
            }
        });



    }
    //TODO search method
    private void searchProduct(String query) {
        ProductManager productManager = new ProductManager();
        productManager.searchProduct(query, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Failed to perform search", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseData = response.body().string();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (responseData != null && !responseData.isEmpty()) {
                            // Parse the search response and display the results
                            List<Product> searchResults = parseSearchResponse(responseData);
                            displaySearchResults(searchResults);
                        } else {
                            Toast.makeText(MainActivity.this, "No results found", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    private List<Product> parseSearchResponse(String response) {
        List<Product> searchResults = new ArrayList<>();
        // Parse the response and populate the searchResults list with Product objects
        // Add your code here to parse the response and extract the necessary information
        // Example: You can split the response by a delimiter and create Product objects
        // based on the retrieved data
        return searchResults;
    }

    private void displaySearchResults(List<Product> searchResults) {
        // Display the search results in a ListView or any other appropriate view
        // Add your code here to display the search results
    }






}