package com.example.pleasework;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class productM extends AppCompatActivity {
    private EditText productNameEditText;
    private EditText productPriceEditText;
    private EditText productDescriptionEditText;
    private EditText productCategoryEditText;
    // Define the product manager instance
    private ProductManager productManager;

    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_m);

        // Initialize the product manager
        productManager = new ProductManager();

        // Find the EditText fields
        productNameEditText = findViewById(R.id.productNameEditText);
        productDescriptionEditText = findViewById(R.id.productDescriptionEditText);
        productPriceEditText = findViewById(R.id.productPriceEditText);
        productCategoryEditText = findViewById(R.id.productCategoryEditText);

        // Add a click listener to the button for image selection
        Button selectImageButton = findViewById(R.id.buttonSelectImage);
        selectImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImagePicker();
            }
        });

        // Add a click listener to the button for adding the product
        Button addProductButton = findViewById(R.id.addProductButton); // Fix the button ID
        addProductButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the product details from user input (e.g., name, description, price, category)
                String productName = productNameEditText.getText().toString();
                String productDescription = productDescriptionEditText.getText().toString();
                double productPrice = Double.parseDouble(productPriceEditText.getText().toString());
                String productCategory = productCategoryEditText.getText().toString();

                ImageView productImageView = findViewById(R.id.productImageView);
                Bitmap bitmap = ((BitmapDrawable) productImageView.getDrawable()).getBitmap();

                // Call the addProduct method of the product manager to add the product
                productManager.addProduct(productName, productDescription, productPrice, productCategory, bitmap, new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(productM.this, "Failed to add product", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        final String responseData = response.body().string();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (responseData.equals("success")) {
                                    Toast.makeText(productM.this, "Product added successfully", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(productM.this, "Failed to add product", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                });
            }
        });
    }

    // Open the image picker activity
    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            Bitmap selectedBitmap = getBitmapFromUri(imageUri);

            // Display the selected image in an ImageView or perform any other operations
            ImageView imageView = findViewById(R.id.productImageView);
            imageView.setImageBitmap(selectedBitmap);
        }
    }

    // Convert the image URI to a Bitmap object
    private Bitmap getBitmapFromUri(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            return BitmapFactory.decodeStream(inputStream);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}