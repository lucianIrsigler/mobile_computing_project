package com.example.logintest;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.logintest.databinding.FragmentViewProductBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FragmentViewProduct extends Fragment {
    private final Product product;
    final HTTPHandler handler = new HTTPHandler();
    final UsersManager usersManager = new UsersManager();
    FragmentViewProductBinding binding;
    FragmentManager manager;

    public FragmentViewProduct(Product product) {
        this.product = product;

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.manager = getParentFragmentManager();

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        utility.replaceFragment(manager,R.id.container1,new EmptyFragment(),"empty");
        utility.replaceFragment(manager,R.id.searchbarContainer,new EmptyFragment(),"empty");

        binding = FragmentViewProductBinding.inflate(inflater, container, false);

        // Access the views in the fragment layout and update them with the product details
        TextView userNameTextView = binding.getRoot().findViewById(R.id.tvUsernameViewProduct);
        TextView productNameTextView = binding.getRoot().findViewById(R.id.tvProductNameViewProduct);
        TextView productPriceTextView = binding.getRoot().findViewById(R.id.tvPriceViewProduct);
        TextView productDescriptionTextView = binding.getRoot().findViewById(R.id.tvDescriptionViewProduct);
        TextView dateOfProduct = binding.getRoot().findViewById(R.id.tvDateViewProduct);
        //RecyclerView showImageRecyclerView = binding.getRoot().findViewById(R.id.view_products_rv);
        Button buyProduct = binding.getRoot().findViewById(R.id.btnBuyNow);
        Button addRating = binding.getRoot().findViewById(R.id.btnAddRating);
        RatingBar ratingBar = binding.getRoot().findViewById(R.id.ratingBar);
        TextView avgStars = binding.getRoot().findViewById(R.id.tvAvgRating);
        ImageSlider showImageSlider = binding.getRoot().findViewById(R.id.view_products_rv);


        productNameTextView.setText(product.getName());
        String price = String.format("R%.2f",product.getPrice());
        productPriceTextView.setText(price);
        productDescriptionTextView.setText(product.getDescription());

        //sets text for views
        try {
            JSONArray productDetails = getProductDetails();

            //set date
            String dateOutput = formatDate(productDetails);
            dateOfProduct.setText(dateOutput);

            //get userID and set username
            int userID = productDetails.getJSONObject(0).getInt("userID");
            userNameTextView.setText(getUsername(userID));

            //get image paths
            JSONArray imagePathResponse = getImagePaths();

            List<SlideModel> slideModels = new ArrayList<SlideModel>();

            for (int i = 0; i < imagePathResponse.length(); i++) {
                String imagePath = imagePathResponse.getJSONObject(i).getString("imagePath");
                String url = "https://lamp.ms.wits.ac.za/home/s2621933/php/getimage.php?imagepath="+imagePath;
                SlideModel slide = new SlideModel(url,ScaleTypes.FIT);
                slideModels.add(slide);
            }

            showImageSlider.setImageList(slideModels);

            //set rating bar and avg star textview
            float avg_stars= getAvgStars();
            try {
                ratingBar.setRating(getAvgStars());
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
            avgStars.setText(Float.toString(avg_stars));

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }


        //set onclicks
        buyProduct.setOnClickListener(view -> {
            FragmentAddress fragment = new FragmentAddress(manager);
            fragment.setArguments(product);
            manager.beginTransaction()
                    .replace(R.id.container,fragment,fragment.getClass().getSimpleName())
                    .addToBackStack(fragment.getClass().getSimpleName())
                    .commit();
        });

        addRating.setOnClickListener(view -> {
            TransactionManager transactionManager = new TransactionManager();
            ProductManager productManager = new ProductManager();

            int productID = product.getProductID();
            long userID = usersManager.getCurrentUserID();


            if (productManager.isSeller(userID,productID)){
                Toast.makeText(getContext(),
                        "Seller can not leave a review",
                        Toast.LENGTH_LONG).show();
            }
            else if (transactionManager.checkTransaction(userID,productID)) {
                showAlert();
                try {
                    ratingBar.setRating(getAvgStars());
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }else{
                Toast.makeText(getContext(),
                        "You must buy the item before you can leave a review",
                        Toast.LENGTH_LONG).show();
            }

            SharedPreferencesManager.initialize(getActivity());
            SharedPreferencesManager.storeUserInfo(new UsersManager().getUserInformation());



        });
        return binding.getRoot();
    }

    /**
     * Search a products details
     * @return the JSONArray of the product details
     * @throws JSONException incase JSONObject creation dies
     */
    private JSONArray getProductDetails() throws JSONException {
        JSONObject params = new JSONObject();
        params.put("productID", product.getProductID());

        return handler.getRequest(
                "https://lamp.ms.wits.ac.za/home/s2621933/php/searchoneproduct.php",
                params, JSONArray.class);
    }

    /**
     * Searches user table to retreive a username
     * @param userID userID to check
     * @return the username for the userID
     * @throws JSONException if something goes wrong with JSONObject
     */
    private String getUsername(long userID) throws JSONException {
        JSONObject userName = usersManager.searchUserInfo(userID);
        return userName.getString("username");
    }

    /**
     *  formats the date output for the textview
     * @param productDetails product details includes "dateAdded"
     * @return the date formated
     * @throws JSONException if something goes wrong with getJSONObject
     */
    private String formatDate(JSONArray productDetails) throws JSONException {
        String dateAdded = productDetails.getJSONObject(0).getString("dateAdded");
        String[] substrings = dateAdded.split("-");
        String day = substrings[2];
        String month = substrings[1];
        String year = substrings[0];
        return day + "/" + month + "/" + year;
    }

    /**
     * Gets image paths for the product
     * @return JSONArray including the image paths
     * @throws JSONException if the params is unable to put "productID"
     */
    private JSONArray getImagePaths() throws JSONException {
        JSONObject params = new JSONObject();
        params.put("productID", product.getProductID());
        return handler.getRequest(
                "https://lamp.ms.wits.ac.za/home/s2621933/php/imageReader.php",
                params, JSONArray.class);
    }
    /**
     * Shows an alert dialog for reviewing a product.
     * Allows user to provide a rating for the product.
     *
     * Upon pressing submit, the rating is added to the product's ratings.
     */
    public void showAlert(){
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.review_product_dialog, null);
        builder.setView(dialogView);

        TextView ratingNum = dialogView.findViewById(R.id.dialog_rating);
        Button submit = dialogView.findViewById(R.id.btnSubmit);
        Button cancel = dialogView.findViewById(R.id.btnCancel);
        RatingBar bar = dialogView.findViewById(R.id.rbRateYourPurchase);
        final AlertDialog alertDialog = builder.create();

        ratingNum.addTextChangedListener(new TextWatcher() {
         @Override
         public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
         }

         @Override
         /**
          * Callback method invoked when the text in the associated TextView has changed.
          *
          * @param charSequence the updated text
          * @param i the start position of the changed text
          * @param i1 the length of the changed text
          * @param i2 the new length after the change
          */
         public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
             if (charSequence.toString().isEmpty()) {
                 bar.setRating(0);
                 return;
             }

             float stars = Float.parseFloat(charSequence.toString());

             if (stars<=5){
                 bar.setRating(stars);
             }else{
                 bar.setRating(0);
             }
         }
         @Override
         public void afterTextChanged(Editable editable) {

         }});

        submit.setOnClickListener(v -> {
            float stars = Float.parseFloat(ratingNum.getText().toString());

            if (stars > 5 || stars<0){
                Toast.makeText(getActivity(), "Invalid rating", Toast.LENGTH_SHORT).show();
                alertDialog.dismiss();
            }
            RatingManager ratingManager = new RatingManager();

            ratingManager.addRating(usersManager.getCurrentUserID(),
                    product.getProductID(),stars);

            alertDialog.dismiss();

            //reload the fragment
            manager.beginTransaction()
                    .replace(R.id.container,new FragmentViewProduct(product),
                            FragmentViewProduct.class.getSimpleName())
                    .addToBackStack(null)
                    .commit();

        });

        cancel.setOnClickListener(v -> alertDialog.dismiss());
        alertDialog.show();
    }

    public float getAvgStars() throws JSONException {
        RatingManager ratingManager = new RatingManager();
        return ratingManager.getAverageRating(product.getProductID());
    }

}